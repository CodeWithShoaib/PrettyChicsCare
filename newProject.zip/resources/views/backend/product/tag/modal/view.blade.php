<table class="table table-bordered">
	<tr><td>{{ _lang('Name') }}</td><td>{{ $tag->translation->name }}</td></tr>
</table>

